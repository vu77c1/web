CREATE PROCEDURE RemoveCompletedProjects
 AS
 BEGIN
     SET NOCOUNT ON; -- To suppress the "xx rows affected" messages

     DECLARE @ThreeMonthsAgo DATE;
     SET @ThreeMonthsAgo = DATEADD(MONTH, -3, GETDATE());

     DECLARE @DeletedProjectsCount INT;

     -- Remove from Work_Done table
     DELETE FROM Work_Done
     WHERE ModuleID IN (
         SELECT ModuleID
         FROM Project_Modules
         WHERE ProjectID IN (
             SELECT ProjectID
             FROM Projects
             WHERE ProjectCompletedOn IS NOT NULL
               AND ProjectCompletedOn <= @ThreeMonthsAgo
         )
     );

     SET @DeletedProjectsCount = @@ROWCOUNT;
     PRINT 'Number of records removed from Work_Done: ' + CAST(@DeletedProjectsCount AS VARCHAR(10));

     -- Remove from Project_Modules table
     DELETE FROM Project_Modules
     WHERE ProjectID IN (
         SELECT ProjectID
         FROM Projects
         WHERE ProjectCompletedOn IS NOT NULL
           AND ProjectCompletedOn <= @ThreeMonthsAgo
     );

     SET @DeletedProjectsCount = @@ROWCOUNT;
     PRINT 'Number of records removed from Project_Modules: ' + CAST(@DeletedProjectsCount AS VARCHAR(10));

     -- Remove from Projects table
     DELETE FROM Projects
     WHERE ProjectCompletedOn IS NOT NULL
       AND ProjectCompletedOn <= @ThreeMonthsAgo;

     SET @DeletedProjectsCount = @@ROWCOUNT;
     PRINT 'Number of records removed from Projects: ' + CAST(@DeletedProjectsCount AS VARCHAR(10));

 END;
go

