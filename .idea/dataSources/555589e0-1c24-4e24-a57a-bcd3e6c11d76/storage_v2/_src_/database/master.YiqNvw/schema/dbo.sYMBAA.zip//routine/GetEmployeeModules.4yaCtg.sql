CREATE PROCEDURE GetEmployeeModules @EmployeeID INT
    AS
    BEGIN
        SELECT PM.ModuleID,
               P.ProjectName,
               PM.ProjectModulesDate,
               PM.ProjectModulesCompletedOn,
               PM.ProjectModulesDescription
        FROM Project_Modules PM
                 INNER JOIN
             Projects P ON PM.ProjectID = P.ProjectID
        WHERE PM.EmployeeID = @EmployeeID;

        -- Add more columns as needed based on your requirements
    END;
go

